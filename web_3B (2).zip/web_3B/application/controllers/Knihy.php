<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Knihy extends CI_Controller {

   function  __construct()
    {
        parent::__construct();
        $this->load->model('knihy_model');
        $this->load->library('session');

        $this->load->library('javascript');

        $this->load->library('form_validation');

        $this->load->library('email');

        $this->load->library(['ion_auth', 'form_validation']);

        $this->load->helper(['url', 'language']);

        $this->session->set_userdata('logged_in',$this->ion_auth->logged_in());

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        
    }

    public function menu()
    {
        $data['polozky'] = $this->knihy_model->get_menu_polozky();
                                
        $this->load->view('layout/hlava', $data);
       
        $this->load->view('layout/pata');
    }

    public function strana($id) 
    {
        $data['knihy'] = $this->knihy_model->get_strana($id);
        $data['polozky'] = $this->knihy_model->get_menu_polozky();
        $data['kategorie'] = $this->knihy_model->get_kategorie($id);

        $this->load->view('layout/hlava', $data);
        $this->load->view('stranky/kategorie');
        $this->load->view('stranky/strana');
        $this->load->view('layout/pata');
    }
    public function anotace($id)
    {
        $data['anotace'] = $this->knihy_model->get_anotace($id);
        $data['polozky'] = $this->knihy_model->get_menu_polozky();
        
        $this->load->view('layout/hlava', $data);
        $this->load->view('stranky/anotace');
        $this->load->view('layout/pata');
    }
   public function formular()
    {  
        $data['polozky'] = $this->knihy_model->get_menu_polozky();
  
        $this->load->view('layout/hlava', $data);
        $this->load->view('stranky/formular');
        $this->load->view('layout/pata');
    }
}
