<?php

if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class knihy_model extends CI_Model {

    public function get_menu_polozky(){
       
        $this->db->select('polozka_menu, id_menu');
	$this->db->from('menu');
        $this->db->order_by('id_menu');
        
        $query = $this->db->get();
        return $query->result();
    }

    public function get_strana($id){

        $sql = "SELECT * FROM knihy WHERE kategorie_id_kategorie = ?";
        $result = $this->db->query($sql, array($id));

        return $result->result();

    }

    public function get_anotace($id){

        $sql = "SELECT * FROM knihy WHERE id_knihy = ?";
        $result = $this->db->query($sql, array($id));

        return $result->result();

    }
    public function get_kategorie($id){
        
        $sql = "SELECT * FROM kategorie WHERE id_kategorie = ?";
        $result = $this->db->query($sql, array($id));

        return $result->result();
    }

    public function menu()
            {
        $this->db->select('*');
	$this->db->from('menu');
        $this->db->order_by('id_menu');
        
        $query = $this->db->get();
        return $query->result();
        
            }
    
    } 