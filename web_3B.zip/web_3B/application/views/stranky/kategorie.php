<div class="container">
<h1>
    <?php foreach($kategorie as $o): ?>
        <?php echo $o->kategorie; ?>
    <?php endforeach; ?>
</h1>
</div>
