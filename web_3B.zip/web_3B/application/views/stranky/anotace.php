<div class="container">
  <table class="table">
  <thead>
    <tr>
      <th scope="col">Kniha</th>
      <th scope="col">Anotace</th>

    </tr>
  </thead>
  <tbody>
     <?php foreach($anotace as $p): ?>
      <tr>
            <td>
                <?php echo $p->nazev_knihy;?>       
            </td>
            <td> 
            <?php echo $p->anotace; ?>
            </td>
  
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
