<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Knihy extends CI_Controller {

   function  __construct()
    {
        parent::__construct();
        $this->load->model('knihy_model');
    }

    public function menu()
    {

        $data['polozky'] = $this->knihy_model->get_menu_polozky();
        //   $data['knihy1'] = $this->knihy_model->get_strana_1();

        
                                
        $this->load->view('layout/hlava', $data);
        //  $this->load->view('stranky/prvni_strana', $data);
        $this->load->view('layout/pata');
    }

    public function strana($id) // parametr id bere z url
    {
        $data['knihy'] = $this->knihy_model->get_strana($id);
        $data['polozky'] = $this->knihy_model->get_menu_polozky();
        $data['kategorie'] = $this->knihy_model->get_kategorie($id);

        $this->load->view('layout/hlava', $data);
        $this->load->view('stranky/kategorie');
        $this->load->view('stranky/strana');
        $this->load->view('layout/pata');
    }
    public function anotace($id)
    
            {
        $data['anotace'] = $this->knihy_model->get_anotace($id);
        $data['polozky'] = $this->knihy_model->get_menu_polozky();
  

        $this->load->view('layout/hlava', $data);
        $this->load->view('stranky/anotace');
        $this->load->view('layout/pata');
    }

}
