-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Počítač: 127.0.0.1
-- Vytvořeno: Pát 09. říj 2020, 12:30
-- Verze serveru: 10.4.14-MariaDB
-- Verze PHP: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `rihak_knihy`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `kategorie`
--

CREATE TABLE `kategorie` (
  `id_kategorie` int(11) NOT NULL,
  `kategorie` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Vypisuji data pro tabulku `kategorie`
--

INSERT INTO `kategorie` (`id_kategorie`, `kategorie`) VALUES
(1, 'Světová a česká literatura do konce 18. stol.'),
(2, 'Světová a česká literatura 19. stol.'),
(3, 'Světová literatura 20. a 21. století'),
(4, 'Česká literatura 20. a 21. století');

-- --------------------------------------------------------

--
-- Struktura tabulky `knihy`
--

CREATE TABLE `knihy` (
  `id_knihy` int(11) NOT NULL,
  `nazev_knihy` varchar(45) DEFAULT NULL,
  `autor` varchar(45) DEFAULT NULL,
  `anotace` text DEFAULT NULL,
  `kategorie_id_kategorie` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Vypisuji data pro tabulku `knihy`
--

INSERT INTO `knihy` (`id_knihy`, `nazev_knihy`, `autor`, `anotace`, `kategorie_id_kategorie`) VALUES
(2, 'Jeptiška', 'Diderot, Denis', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur bibendum justo non orci. Fusce aliquam vestibulum ipsum. Curabitur sagittis hendrerit ante. Donec iaculis gravida nulla. Phasellus faucibus molestie nisl. Integer imperdiet lectus quis justo. Etiam egestas wisi a erat. Nunc tincidunt ante vitae massa. In laoreet, magna id viverra tincidunt, sem odio bibendum justo, vel imperdiet sapien wisi sed libero. Duis viverra diam non justo.', 1),
(3, 'Robinson Crusoe', 'Defoe, Daniel', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur bibendum justo non orci. Fusce aliquam vestibulum ipsum. Curabitur sagittis hendrerit ante. Donec iaculis gravida nulla. Phasellus faucibus molestie nisl. Integer imperdiet lectus quis justo. Etiam egestas wisi a erat. Nunc tincidunt ante vitae massa. In laoreet, magna id viverra tincidunt, sem odio bibendum justo, vel imperdiet sapien wisi sed libero. Duis viverra diam non justo.', 1),
(4, 'Labyrint světa a ráj srdce ', 'Komenský, Jan Amos', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur bibendum justo non orci. Fusce aliquam vestibulum ipsum. Curabitur sagittis hendrerit ante. Donec iaculis gravida nulla. Phasellus faucibus molestie nisl. Integer imperdiet lectus quis justo. Etiam egestas wisi a erat. Nunc tincidunt ante vitae massa. In laoreet, magna id viverra tincidunt, sem odio bibendum justo, vel imperdiet sapien wisi sed libero. Duis viverra diam non justo.', 1),
(5, 'Utrpení mladého Werthera ', 'Goethe, Johann Wolfgang', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur bibendum justo non orci. Fusce aliquam vestibulum ipsum. Curabitur sagittis hendrerit ante. Donec iaculis gravida nulla. Phasellus faucibus molestie nisl. Integer imperdiet lectus quis justo. Etiam egestas wisi a erat. Nunc tincidunt ante vitae massa. In laoreet, magna id viverra tincidunt, sem odio bibendum justo, vel imperdiet sapien wisi sed libero. Duis viverra diam non justo.', 1),
(6, 'Otec Goriot ', 'Balzac, Honoré de', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur bibendum justo non orci. Fusce aliquam vestibulum ipsum. Curabitur sagittis hendrerit ante. Donec iaculis gravida nulla. Phasellus faucibus molestie nisl. Integer imperdiet lectus quis justo. Etiam egestas wisi a erat. Nunc tincidunt ante vitae massa. In laoreet, magna id viverra tincidunt, sem odio bibendum justo, vel imperdiet sapien wisi sed libero. Duis viverra diam non justo.', 2),
(7, 'Pýcha a předsudek ', 'Austenová, Jane', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur bibendum justo non orci. Fusce aliquam vestibulum ipsum. Curabitur sagittis hendrerit ante. Donec iaculis gravida nulla. Phasellus faucibus molestie nisl. Integer imperdiet lectus quis justo. Etiam egestas wisi a erat. Nunc tincidunt ante vitae massa. In laoreet, magna id viverra tincidunt, sem odio bibendum justo, vel imperdiet sapien wisi sed libero. Duis viverra diam non justo.', 2),
(8, 'Nový epochální výlet pana Broučka, tentokráte', 'Čech, Svatopluk', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur bibendum justo non orci. Fusce aliquam vestibulum ipsum. Curabitur sagittis hendrerit ante. Donec iaculis gravida nulla. Phasellus faucibus molestie nisl. Integer imperdiet lectus quis justo. Etiam egestas wisi a erat. Nunc tincidunt ante vitae massa. In laoreet, magna id viverra tincidunt, sem odio bibendum justo, vel imperdiet sapien wisi sed libero. Duis viverra diam non justo.', 2),
(9, 'Cizinec ', 'Camus, Albert', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur bibendum justo non orci. Fusce aliquam vestibulum ipsum. Curabitur sagittis hendrerit ante. Donec iaculis gravida nulla. Phasellus faucibus molestie nisl. Integer imperdiet lectus quis justo. Etiam egestas wisi a erat. Nunc tincidunt ante vitae massa. In laoreet, magna id viverra tincidunt, sem odio bibendum justo, vel imperdiet sapien wisi sed libero. Duis viverra diam non justo.', 3),
(10, 'Matka Kuráž a její děti ', 'Brecht, Bertolt', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur bibendum justo non orci. Fusce aliquam vestibulum ipsum. Curabitur sagittis hendrerit ante. Donec iaculis gravida nulla. Phasellus faucibus molestie nisl. Integer imperdiet lectus quis justo. Etiam egestas wisi a erat. Nunc tincidunt ante vitae massa. In laoreet, magna id viverra tincidunt, sem odio bibendum justo, vel imperdiet sapien wisi sed libero. Duis viverra diam non justo.', 3),
(11, 'Sbohem, armádo ', 'Hemingway, Ernest', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur bibendum justo non orci. Fusce aliquam vestibulum ipsum. Curabitur sagittis hendrerit ante. Donec iaculis gravida nulla. Phasellus faucibus molestie nisl. Integer imperdiet lectus quis justo. Etiam egestas wisi a erat. Nunc tincidunt ante vitae massa. In laoreet, magna id viverra tincidunt, sem odio bibendum justo, vel imperdiet sapien wisi sed libero. Duis viverra diam non justo.', 3),
(12, 'Proměna ', 'Kafka, Franz', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur bibendum justo non orci. Fusce aliquam vestibulum ipsum. Curabitur sagittis hendrerit ante. Donec iaculis gravida nulla. Phasellus faucibus molestie nisl. Integer imperdiet lectus quis justo. Etiam egestas wisi a erat. Nunc tincidunt ante vitae massa. In laoreet, magna id viverra tincidunt, sem odio bibendum justo, vel imperdiet sapien wisi sed libero. Duis viverra diam non justo.', 3),
(13, 'Slezské písně ', 'Bezruč, Petr', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur bibendum justo non orci. Fusce aliquam vestibulum ipsum. Curabitur sagittis hendrerit ante. Donec iaculis gravida nulla. Phasellus faucibus molestie nisl. Integer imperdiet lectus quis justo. Etiam egestas wisi a erat. Nunc tincidunt ante vitae massa. In laoreet, magna id viverra tincidunt, sem odio bibendum justo, vel imperdiet sapien wisi sed libero. Duis viverra diam non justo.', 4),
(14, 'Bílá nemoc ', 'Čapek, Karel', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur bibendum justo non orci. Fusce aliquam vestibulum ipsum. Curabitur sagittis hendrerit ante. Donec iaculis gravida nulla. Phasellus faucibus molestie nisl. Integer imperdiet lectus quis justo. Etiam egestas wisi a erat. Nunc tincidunt ante vitae massa. In laoreet, magna id viverra tincidunt, sem odio bibendum justo, vel imperdiet sapien wisi sed libero. Duis viverra diam non justo.', 4),
(15, 'Povídky z jedné kapsy', 'Čapek, Karel', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur bibendum justo non orci. Fusce aliquam vestibulum ipsum. Curabitur sagittis hendrerit ante. Donec iaculis gravida nulla. Phasellus faucibus molestie nisl. Integer imperdiet lectus quis justo. Etiam egestas wisi a erat. Nunc tincidunt ante vitae massa. In laoreet, magna id viverra tincidunt, sem odio bibendum justo, vel imperdiet sapien wisi sed libero. Duis viverra diam non justo.', 4),
(16, 'Moji přátelé ', 'Deml, Jakub', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur bibendum justo non orci. Fusce aliquam vestibulum ipsum. Curabitur sagittis hendrerit ante. Donec iaculis gravida nulla. Phasellus faucibus molestie nisl. Integer imperdiet lectus quis justo. Etiam egestas wisi a erat. Nunc tincidunt ante vitae massa. In laoreet, magna id viverra tincidunt, sem odio bibendum justo, vel imperdiet sapien wisi sed libero. Duis viverra diam non justo.', 4),
(17, 'Válka s mloky ', 'Čapek, Karel', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur bibendum justo non orci. Fusce aliquam vestibulum ipsum. Curabitur sagittis hendrerit ante. Donec iaculis gravida nulla. Phasellus faucibus molestie nisl. Integer imperdiet lectus quis justo. Etiam egestas wisi a erat. Nunc tincidunt ante vitae massa. In laoreet, magna id viverra tincidunt, sem odio bibendum justo, vel imperdiet sapien wisi sed libero. Duis viverra diam non justo.', 4),
(18, 'Konec masopustu ', 'Topol, Josef', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur bibendum justo non orci. Fusce aliquam vestibulum ipsum. Curabitur sagittis hendrerit ante. Donec iaculis gravida nulla. Phasellus faucibus molestie nisl. Integer imperdiet lectus quis justo. Etiam egestas wisi a erat. Nunc tincidunt ante vitae massa. In laoreet, magna id viverra tincidunt, sem odio bibendum justo, vel imperdiet sapien wisi sed libero. Duis viverra diam non justo.', 4),
(19, 'Markéta Lazarová', 'Vančura, Vladislav', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur bibendum justo non orci. Fusce aliquam vestibulum ipsum. Curabitur sagittis hendrerit ante. Donec iaculis gravida nulla. Phasellus faucibus molestie nisl. Integer imperdiet lectus quis justo. Etiam egestas wisi a erat. Nunc tincidunt ante vitae massa. In laoreet, magna id viverra tincidunt, sem odio bibendum justo, vel imperdiet sapien wisi sed libero. Duis viverra diam non justo.', 4);

-- --------------------------------------------------------

--
-- Struktura tabulky `menu`
--

CREATE TABLE `menu` (
  `id_menu` int(11) NOT NULL,
  `polozka_menu` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Vypisuji data pro tabulku `menu`
--

INSERT INTO `menu` (`id_menu`, `polozka_menu`) VALUES
(1, '1. období'),
(2, '2. období'),
(3, '3. období'),
(4, '4. období');

--
-- Klíče pro exportované tabulky
--

--
-- Klíče pro tabulku `kategorie`
--
ALTER TABLE `kategorie`
  ADD PRIMARY KEY (`id_kategorie`);

--
-- Klíče pro tabulku `knihy`
--
ALTER TABLE `knihy`
  ADD PRIMARY KEY (`id_knihy`);

--
-- Klíče pro tabulku `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id_menu`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `knihy`
--
ALTER TABLE `knihy`
  MODIFY `id_knihy` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
